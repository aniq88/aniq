def test_assert_true():
    assert True

def test_assert_false():
    assert False